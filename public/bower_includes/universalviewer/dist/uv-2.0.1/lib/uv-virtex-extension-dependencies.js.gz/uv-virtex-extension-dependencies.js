define(function() {
    return {
        dependencies: ['virtex', 'three.min', 'Detector', 'stats.min', 'iiif-metadata-component']
    };
});
