define(function() {
    return {
        dependencies: ['l10n', 'pdf_combined', 'pdfobject', 'iiif-metadata-component']
    };
});
