define(function() {
    return {
        dependencies: ['mediaelement-and-player', 'iiif-metadata-component']
    };
});
