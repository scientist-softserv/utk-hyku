define(function() {
    return {
        dependencies: ['iiif-tree-component', 'iiif-gallery-component', 'iiif-metadata-component', 'openseadragon.min']
    };
});
